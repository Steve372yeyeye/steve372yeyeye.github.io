#!/usr/bin/bash

clear
echo 检查依赖
apt install proot-distro -y

##################

##############

##################
ARCH_(){
	case $(dpkg --print-architecture) in
		arm64|aarch*)
			echo "arm64"
			ARCH=arm64 ;;
		x86_64|amd64) 
			echo "amd64"
			ARCH=amd64 ;;
		i*86|x86)
			echo "i386"
			ARCH=i386 ;;
		armv7*|armv8l)
			echo "armhf"
			ARCH=armhf ;;
		armv6*|armv5*)
			echo "armel"
			ARCH=armel ;;
		ppc*)
			echo "ppc64el"
			ARCH=ppc64el ;;
		s390*)
			echo "s390x"
			ARCH=s390x ;;
		*) echo "不被识别"
		echo -e "\nexit...\n"
		sleep 1
		exit ;;
esac
}

#####################

SYS_SELECT() {
	echo -e "请选择系统
	1) debian
	2) ubuntu
	3) kali
	4) centos
	5) arch
	6) fedora
	7) 从本地安装
	0) 退出"
read -r -p "请选择:" input
case $input in
	1) echo -e "选择debian哪个版本
		1) buster
		2) bullseye
		3) sid
		9) 返回主目录
		0) 退出"
		read -r -p "请选择:" input
		case $input in
			1) echo "即将下载安装debian(buster)"
		sys_name=buster
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/debian/buster/$ARCH/default/" ;;
	2) echo "即将下载安装debian(bullseye)"        
		sys_name=bullseye  
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/debian/bullseye/$ARCH/default/" ;;
	3) echo "即将下载安装debian(sid)"
		sys_name=sid
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/debian/sid/$ARCH/default/" ;;
		9) MAIN ;;
		0) echo -e "\nexit"
			sleep 1                           
			exit 0 ;;                           
	*) INVALID_INPUT                                     
		SYS_SELECT ;;
esac ;;
2) echo -e "选择ubuntu哪个版本                            
	1) bionic
	2) focal
	3) impish
	0) 退出"                                          
	read -r -p "请选择:" input                          
	case $input in
	1) echo "即将下载安装ubuntu(bionic)"
		sys_name=bionic
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/ubuntu/bionic/$ARCH/default/" ;;
	2) echo "即将下载安装ubuntu(focal)"
		sys_name=focal
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/ubuntu/focal/$ARCH/default/" ;;
	3) echo "即将下载安装ubuntu(impish)"
		sys_name=impish
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/ubuntu/impish/$ARCH/default/" ;;
	9) MAIN ;;                         
		0) echo -e "\nexit"     
			sleep 1                               
			exit 0 ;;                         
		*) INVALID_INPUT                             
			SYS_SELECT ;;
	esac ;;
	3) echo "即将下载安装kali"
                sys_name=kali
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/kali/current/$ARCH/default/" ;;
	4) echo "即将下载安装centos"
                sys_name=centos
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/centos/9-Stream/$ARCH/default/" ;;
	5) echo "即将下载安装arch"
                sys_name=arch
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/archlinux/current/$ARCH/default/" ;;
	6) echo "即将下载安装fedora"
		sys_name=fedora       
		DEF_CUR="https://mirrors.bfsu.edu.cn/lxc-images/images/fedora/33/$ARCH/default/" ;;
	7) 
	echo 请确保您的文件已经放入
     echo "/sdcard/download/"目录
     echo 请输入要安装的文件名
     echo 默认格式为 .tar.xz
     echo 如果不是此格式的文件可能将无法解压
     echo 请输入文件名:
     read -p " " namel
     echo 请输入要安装的系统名字
     echo 是rootfs文件的所属的系统
     echo 尽量是系统版本代号
     read -p " " sys_name
     echo "获取: /sdcard/download/$namel "
      cp /sdcard/download/$namel    ./rootfs.tar.xz
      echo -e "正在解压系统包"
      mkdir $sys_name-$AH
		tar xvf ${BAGNAME} -C $sys_name-$AH 2>/dev/null
		rm ${BAGNAME}
      SYS_SET
      FIN
      sleep 1
	 ;;
	0) echo -e "\nexit..."
		sleep 1
		exit 0 ;;

	*) INVALID_INPUT
		SYS_SELECT ;;
esac
}
#####################

#####################

SYS_DOWN() {
BAGNAME="rootfs.tar.xz"
        if [ -e ${BAGNAME} ]; then
                rm -rf ${BAGNAME}
	fi
	curl -o ${BAGNAME} ${DEF_CUR}
		VERSION=`cat ${BAGNAME} | grep href | tail -n 2 | cut -d '"' -f 4 | head -n 1`
		curl -o ${BAGNAME} ${DEF_CUR}${VERSION}${BAGNAME}
		if [ $? -ne 0 ]; then
			echo -e "${RED}下载失败，请重输${RES}\n"
			MAIN
		fi
		if [ -e $sys_name-$AH ]; then
			rm -rf $sys_name-$AH
		fi
        
		mkdir $sys_name-$AH
#tar xvf rootfs.tar.xz -C ${BAGNAME}
echo -e "正在解压系统包"
		tar xf ${BAGNAME} -C $sys_name-$AH 2>/dev/null
		rm ${BAGNAME}
                echo -e "$sys_name-$AH系统已下载，文件夹名为$sys_name-$AH"
}
####################
SYS_SET() {
	echo "更新DNS"
	sleep 1
	echo "127.0.0.1 localhost" > $sys_name-$AH/etc/hosts
	rm -rf $sys_name-$AH/etc/resolv.conf &&
	echo "nameserver 223.5.5.5
nameserver 223.6.6.6" >$sys_name-$AH/etc/resolv.conf
echo "设置时区"
sleep 1
	echo "export  TZ='Asia/Shanghai'" >> $sys_name-$AH/root/.bashrc
	echo 检测到你没有权限读取/proc内的所有文件
	echo 将自动伪造新文件
	git clone https://gitee.com/yudezeng/proot_proc.git
	mkdir tmp
	tar xvJf proot_proc/proc.tar.xz -C tmp 
	cp -rv tmp/usr/local/etc/tmoe-linux/proot_proc tmp/
	cp -rv tmp/proot_proc $sys_name-$AH/etc/proc
	rm proot_proc tmp -rfv
	if grep -q 'ubuntu' "$sys_name-$AH/etc/os-release" ; then
        touch "$sys_name-$AH/root/.hushlogin"
fi
}
####################
FIN(){
echo "写入启动脚本"
echo "为了兼容性考虑已将内核信息伪造成5.17.18-perf"
sleep 1
cat > $sys_name-$AH.sh <<- EOM
#!/bin/bash
unset LD_PRELOAD
proot --bind=/vendor --bind=/system --bind=/data/data/com.termux/files/usr --bind=/storage --bind=/storage/self/primary:/sdcard --bind=/data/data/com.termux/files/home --bind=/data/data/com.termux/cache --bind=/data/dalvik-cache --bind=$sys_name-$AH/tmp:/dev/shm --bind=$sys_name-$AH/etc/proc/vmstat:/proc/vmstat --bind=$sys_name-$AH/etc/proc/version:/proc/version --bind=$sys_name-$AH/etc/proc/uptime:/proc/uptime --bind=$sys_name-$AH/etc/proc/stat:/proc/stat --bind=$sys_name-$AH/etc/proc/loadavg:/proc/loadavg --bind=/sys --bind=/proc/self/fd/2:/dev/stderr --bind=/proc/self/fd/1:/dev/stdout --bind=/proc/self/fd/0:/dev/stdin --bind=/proc/self/fd:/dev/fd --bind=/proc --bind=/dev/urandom:/dev/random --bind=/dev --root-id --cwd=/root -L --kernel-release=5.17.18-perf --sysvipc --link2symlink --kill-on-exit --rootfs=$sys_name-$AH/ /usr/bin/env -i HOME=/root LANG=C.UTF-8 TERM=xterm-256color /bin/su -l root
EOM

echo "授予启动脚本执行权限"
sleep 1
chmod +x $sys_name-$AH.sh
if [ -e ${PREFIX}/etc/bash.bashrc ]; then
	if ! grep -q 'pulseaudio' ${PREFIX}/etc/bash.bashrc; then
		sed -i "1i\pkill -9 pulseaudio" ${PREFIX}/etc/bash.bashrc
	fi
else
	sed -i "1i\pkill -9 pulseaudio" $sys_name-$AH.sh
fi
echo -e "现在可以执行 ./$sys_name-$AH.sh 运行 $sys_name-$AH系统"
sleep 1
exit 1
}
####################
MAIN(){
     echo "
      1)安装$ARCH容器
      2)安装恢复包
      3)导出系统
      4)安装x64架构的容器
      0)退出
     
      "
     read -p " " opt
     case $opt in
     
     1)
     ARCH=$(ARCH_)
     AH=$(ARCH_)
     SYS_SELECT "$@"
     SYS_DOWN
     SYS_SET
     FIN
     ;;
     2)
     echo 请确保您的文件已经放入
     echo "/sdcard/download/"目录
     echo 请输入要安装的文件名
     echo 默认格式为 .tar.xz
     echo 如果不是此格式的文件可能将无法解压
     ls /sdcard/Download/
     echo 请输入文件名:
     read -p " " namel
     echo 请输入要安装的系统名字
     echo 是rootfs文件的所属的系统
     echo 尽量是系统版本代号
     
     read -p " " sys_name
     echo 请输入架构
     read -p " " AH
     
     echo "获取: /sdcard/download/$namel "
      cp /sdcard/download/$namel    ./rootfs.tar.xz
      echo -e "正在解压系统包"
		tar xvf ${BAGNAME}  2>/dev/null
		rm ${BAGNAME}
      SYS_SET
      FIN
      sleep 1
      ;;
      3)echo "请输入此目录的容器系统目录名称"
      echo 如果没有这个目录
      echo 则放弃备份
      ls
      read -p " " sys_name
      tar cvf $sys_name.tar.zstd $sys_name/*
      cp $sys_name.tar.zstd /sdcard/Download/$sys_name.tar.zstd
      rm  $sys_name.tar.zstd
      echo 容器系统已备份到/sdcard/Download/$sys_name.tar.zstd
      ;;
      4)
      ARCH=amd64
      AH=amd64
      SYS_SELECT "$@"
      SYS_DOWN
      SYS_SET
      FIN_
      ;;
      esac
}
FIN_(){
echo "配置qemu"
sleep 2
mkdir termux_tmp && cd termux_tmp
CURL_T=`curl https://mirrors.bfsu.edu.cn/debian/pool/main/q/qemu/ | grep '\.deb' | grep 'qemu-user-static' | grep arm64 | tail -n 1 | cut -d '=' -f 3 | cut -d '"' -f 2`
curl -o qemu.deb https://mirrors.bfsu.edu.cn/debian/pool/main/q/qemu/$CURL_T
apt install binutils
ar -vx qemu.deb
tar xvf data.tar.xz
cd && cp termux_tmp/usr/bin/qemu-x86_64-static $sys_name-$AH/ && rm -rf termux_tmp
echo "删除临时文件"
sleep 1
echo "创建登录系统脚本"
sleep 1
echo "
#!/bin/bash
unset LD_PRELOAD
proot --bind=/vendor --bind=/system --bind=/data/data/com.termux/files/usr --bind=/storage --bind=/storage/self/primary:/sdcard --bind=/data/data/com.termux/files/home --bind=/data/data/com.termux/cache --bind=/data/dalvik-cache --bind=$sys_name-$AH/tmp:/dev/shm --bind=$sys_name-$AH/etc/proc/vmstat:/proc/vmstat --bind=$sys_name-$AH/etc/proc/version:/proc/version --bind=$sys_name-$AH/etc/proc/uptime:/proc/uptime --bind=$sys_name-$AH/etc/proc/stat:/proc/stat --bind=$sys_name-$AH/etc/proc/loadavg:/proc/loadavg --bind=/sys --bind=/proc/self/fd/2:/dev/stderr --bind=/proc/self/fd/1:/dev/stdout --bind=/proc/self/fd/0:/dev/stdin --bind=/proc/self/fd:/dev/fd --bind=/proc --bind=/dev/urandom:/dev/random --bind=/dev --root-id --cwd=/root -L --kernel-release=5.17.18-perf --sysvipc --link2symlink --kill-on-exit  -q $sys_name-$AH/qemu-x86_64-static --rootfs=$sys_name-$AH/ /usr/bin/env -i HOME=/root LANG=C.UTF-8 TERM=xterm-256color /bin/su -l root ">$sys_name-$AH.sh
echo "赋予执行权限"
sleep 1
chmod +x $sys_name-$AH.sh
echo -e "${YELLOW}现在可以执行 ./$sys_name-$AH.sh 运行 $sys_name-$AH 了"
sleep 2
exit 1
}
####
MAIN "$@"